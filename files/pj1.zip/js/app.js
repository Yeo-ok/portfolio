/*!
* Start Bootstrap - Grayscale v7.0.6 (https://startbootstrap.com/theme/grayscale)
* Copyright 2013-2023 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-grayscale/blob/master/LICENSE)
*/
//
// Scripts
// 

window.addEventListener('DOMContentLoaded', event => {

    // Navbar shrink function
    var navbarShrink = function () {
        const navbarCollapsible = document.body.querySelector('#mainNav');
        if (!navbarCollapsible) {
            return;
        }
        if (window.scrollY === 0) {
            navbarCollapsible.classList.remove('navbar-shrink')
        } else {
            navbarCollapsible.classList.add('navbar-shrink')
        }

    };

    // Shrink the navbar 
    navbarShrink();

    // Shrink the navbar when page is scrolled
    document.addEventListener('scroll', navbarShrink);

    // Activate Bootstrap scrollspy on the main nav element
    const mainNav = document.body.querySelector('#mainNav');
    if (mainNav) {
        new bootstrap.ScrollSpy(document.body, {
            target: '#mainNav',
            rootMargin: '0px 0px -40%',
        });
    };

    // Collapse responsive navbar when toggler is visible
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#navbarResponsive .nav-link')
    );
    responsiveNavItems.map(function (responsiveNavItem) {
        responsiveNavItem.addEventListener('click', () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                navbarToggler.click();
            }
        });
    });

});

    //한글자씩 나타나는 표현 함수
    const content = "개발자 진태우란?";
    const text = document.querySelector(".typAni");
    let i = 0;

    function typing(){
        if (i < content.length) {
            let txt = content.charAt(i);
            text.innerHTML += txt;
            i++;
        }
    }
    //한글자씩 나타나는 효과를 2초후 실행
    setTimeout(function(){
        setInterval(typing, 200);
    },2000)

    //검색 버튼이 깜빡이는 효과를 5초후 실행
    setTimeout(function(){
        $('.btnSearch').addClass('blink')
    },5000)
    
    //프로젝트 사진 확대 및 축소 인덱스는 0부터이고, 인덱스가 짝수인 것은 좌에서 우로 확대 인덱스가 홀수인 것은 우에서 좌로 확대
    function imgScale(){
        $('.pImg:even').on('mouseover', function(){
            $('.pImg:even').addClass('pImgLeft');   
        })
        $('.pImg:even').on('mouseout', function(){
            $('.pImg:even').removeClass('pImgLeft')
        })
        $('.pImg:odd').on('mouseover', function(){
            $('.pImg:odd').addClass('pImgRight');
        })
        $('.pImg:odd').on('mouseout', function(){
            $('.pImg:odd').removeClass('pImgRight')
        })
    }
 

//더보기 누를시 추가 프로젝트 화면 생김
// $('.more').on('click',function(){
//     $('.more').addClass('hide');
//     $('.pj').append(`<!-- Project One Row-->
//     <div class="row gx-0 mb-5 mb-lg-0 justify-content-center">
//         <div class="col-lg-6 "><img class="img-fluid pImg" src="images/project2.jpg" alt="..." /></div>
//         <div class="col-lg-6">
//             <div class="bg-black text-center h-100 project">
//                 <div class="d-flex h-100">
//                     <div class="project-text w-100 my-auto text-center text-lg-left">
//                         <h4 class="text-white my-4">프로젝트명</h4>
//                         <p class="mb-0 text-white-50 text-start">프로젝트 내용
//                             기간 : 20xx-xx-xx ~ 20xx-xx-xx<br>
//                             인원 : x인<br>
//                             내용 : 아직 없음
//                         </p>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     </div>
//     <!-- Project Two Row-->
//     <div class="row gx-0 justify-content-center">
//         <div class="col-lg-6"><img class="img-fluid pImg" src="images/project2.jpg" alt="..." /></div>
//         <div class="col-lg-6 order-lg-first">
//             <div class="bg-black text-center h-100 project">
//                 <div class="d-flex h-100">
//                     <div class="project-text w-100 my-auto text-center text-lg-right">
//                         <h4 class="text-white my-4">프로젝트명</h4>
//                         <p class="mb-0 text-white-50 text-start">
//                             기간 : 20xx-xx-xx ~ 20xx-xx-xx<br>
//                             인원 : x인<br>
//                             내용 : 아직 없음
//                         </p>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     </div>`)
// })
imgScale();
rootProject.name = "night-factory"
